#ifndef LISTA_H_INCLUDED
#define LISTA_H_INCLUDED

#include <stdlib.h>

#define DUPLICADO 0
#define NO_EXISTE 0
#define SIN_MEMORIA 0
#define FIN_LISTA 0
#define TODO_OK 1

typedef int (*t_cmp)(const void *, const void*);
typedef struct s_nodo{
    void * info;
    struct s_nodo * psig;
}t_nodo;

typedef struct{
    t_nodo * pri;
    size_t tam_info;
    t_nodo * sig;
    char fin;
}t_lista;

void crear_lista(t_lista * pl, size_t tam_info);
int insertar_en_lista_ordenada(t_lista * pl, const void * info, t_cmp cmp_info);
int eliminar_de_lista_ordenada(t_lista * pl, void * info, t_cmp cmp_info);
void ordenar_lista(t_lista * pl, t_cmp cmp_info);
int lista_vacia(t_lista * pl);
int lista_llena(t_lista * pl);
int obtener_primero_lista(t_lista * pl, void * info);
int obtener_siguiente_lista(t_lista * pl, void * info);
int es_fin_lista(t_lista * pl);


#endif // LISTA_H_INCLUDED
