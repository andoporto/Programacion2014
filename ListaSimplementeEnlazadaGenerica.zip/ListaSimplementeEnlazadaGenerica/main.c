#include <stdio.h>
#include <stdlib.h>
#include "lista.h"

int cmp_num (const void * v1, const void * v2)
{
    int * e1 = (int*) v1, *e2 = (int*) v2;
    return *e1-*e2;
}

int main()
{
    int nums [] = {45,2,38,26,65,11,13,77,99,1,100,65,3,6,8}, i;
    t_lista lista;
    crear_lista(&lista, sizeof(int));
    for(i=0;i<15;i++){
        insertar_en_lista_ordenada(&lista, &nums[i], cmp_num);
    }
    obtener_primero_lista(&lista, &i);
    while(!es_fin_lista(&lista)){
        printf("\n- %d -", i);
        obtener_siguiente_lista(&lista, &i);
    }

    i = 77;
    eliminar_de_lista_ordenada(&lista,&i,cmp_num);
    printf("\n\n Listado despues de eliminar:");
    obtener_primero_lista(&lista, &i);
    while(!es_fin_lista(&lista)){
        printf("\n- %d -", i);
        obtener_siguiente_lista(&lista, &i);
    }
    return 0;
}
