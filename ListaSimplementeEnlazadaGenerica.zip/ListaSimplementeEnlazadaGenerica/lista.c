#include "lista.h"
#include <string.h>
#include <stdio.h>
void crear_lista(t_lista * pl, size_t tam_info)
{
    pl->pri = NULL;
    pl->sig = NULL;
    pl->tam_info = tam_info;
    pl->fin = 1;
}
int insertar_en_lista_ordenada(t_lista * pl, const void * info, t_cmp cmp_info)
{
    t_nodo * pn_nuevo, ** pn = &pl->pri;
    int comp;
    while (*pn && (comp=cmp_info((*pn)->info, info))< 0)
        pn = &(*pn)->psig;
    if (*pn && !comp) return DUPLICADO;
    pn_nuevo = (t_nodo *) malloc(sizeof(t_nodo));
    if (!pn_nuevo) return SIN_MEMORIA;
    pn_nuevo->info = malloc(pl->tam_info);
    if (!pn_nuevo->info)
    {
        free(pn_nuevo);
        return SIN_MEMORIA;
    }
    memcpy(pn_nuevo->info, info, pl->tam_info);
    pn_nuevo->psig = *pn;
    *pn = pn_nuevo;
    return TODO_OK;
}

int eliminar_de_lista_ordenada(t_lista * pl, void * info, t_cmp cmp_info)
{
    t_nodo * pn_aux, ** pn = &pl->pri;
    int comp;
    while (*pn && (comp=cmp_info((*pn)->info, info))< 0)
        pn = &(*pn)->psig;
    if (!*pn || comp) return NO_EXISTE;
    pn_aux = *pn;
    memcpy(info, pn_aux->info, pl->tam_info);
    *pn = pn_aux->psig;
    free(pn_aux->info);
    free(pn_aux);
    return TODO_OK;
}
void ordenar_lista(t_lista * pl, t_cmp cmp_info)
{

}
int lista_vacia(t_lista * pl)
{
    return pl->pri?0:1;
}
int lista_llena(t_lista * pl)
{
    t_nodo * pn_nuevo = (t_nodo *) malloc(sizeof(t_nodo));
    void * info = malloc(pl->tam_info);
    free(pn_nuevo);
    free(info);
    return !info || !pn_nuevo;
}
int obtener_primero_lista(t_lista * pl, void * info)
{
    pl->sig = pl->pri;
    if (!pl->sig)
    {
        pl->fin = 1;
        return FIN_LISTA;
    }
    memcpy(info, pl->sig->info, pl->tam_info);
    pl->fin = 0;
    return TODO_OK;
}
int obtener_siguiente_lista(t_lista * pl, void * info)
{
    if (pl->fin) return FIN_LISTA;
    pl->sig = pl->sig->psig;
    if (!pl->sig)
    {
        pl->fin = 1;
        return FIN_LISTA;
    }
    memcpy(info, pl->sig->info, pl->tam_info);
    return TODO_OK;
}
int es_fin_lista(t_lista * pl)
{
    return (int)pl->fin;
}
