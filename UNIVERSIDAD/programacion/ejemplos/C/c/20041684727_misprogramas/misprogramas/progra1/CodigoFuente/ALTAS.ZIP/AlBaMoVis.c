#include <conio.h>
#include <stdio.h>
#define MAX 1000
#define LV 15

unsigned char menu();
void altas();
void bajas();
void modificaciones();
void consultas();
void pantalla_datos();
void cabeceras();
struct limites desde_hasta();
char pregunte_s_n(char *);
char tipos[5][25]={"contado","normal","preferente","especial","extra"};
int descuentos[5]={0,5,10,20,30};
struct cliente
{
  char nombre[15];
  char direccion[30];
  int tipo;
  char control_alta;
};
struct limites
{
  int inicio;
  int fin;
};

main()
{
  unsigned char opcion;
  while(toupper(opcion=menu())!='F')
  {
    switch(opcion)
    {
      case '1':altas();
		break;
      case '2':bajas();
		break;
      case '3':modificaciones();
		break;
      case '4':consultas();
		break;
    }
  }
}

unsigned char menu()
{
  unsigned char op;
  clrscr();
  gotoxy(10,10);printf("MENU DE MANTENIMIENTO");
  gotoxy(10,11);printf("=====================");
  gotoxy(14,14);printf("1-->Altas");
  gotoxy(14,15);printf("2-->Bajas");
  gotoxy(14,16);printf("3-->Modificaciones");
  gotoxy(14,17);printf("4-->Consultas");
  gotoxy(14,20);printf("F-->Fin");
  gotoxy(10,23);printf("Introduzca opcion:");
  while(op=toupper(getch()),(op<'1'||op>'4')&&op!='F');
  return(op);
}

void altas()
{
  FILE *canal;
  struct cliente cli;
  int num_cli;
  while((canal=fopen("CLIENTES","r+b"))==NULL)
  {
    canal=fopen("CLIENTES","wb");
    fclose(canal);
  }
  do
  {
   pantalla_datos();
   gotoxy(21,7);
   do
   {
     gotoxy(21,7);printf("		");
     gotoxy(21,7);scanf("%d",&num_cli);
   }while(num_cli<1||num_cli>MAX);
   cli.control_alta='0';
   fseek(canal,(num_cli-1)*sizeof(struct cliente),SEEK_SET);
   fread(&cli,sizeof(struct cliente),1,canal);
   if(cli.control_alta=='1')
   {
     gotoxy(10,20);printf("Cliente ya existente");
     continue;
   }
   gotoxy(21,9);scanf("%s",cli.nombre);
   gotoxy(21,11);scanf("%s",cli.direccion);
   do
   {
     gotoxy(21,13);printf("		");
     gotoxy(21,13);scanf("%d",&cli.tipo);
   }while(cli.tipo<1||cli.tipo>5);
   gotoxy(25,13);printf("Cliente %s",tipos[cli.tipo-1]);
   gotoxy(65,13);printf("%d",descuentos[cli.tipo-1]);
   if(pregunte_s_n("Correcto?(S/N):")=='S')
   {
    cli.control_alta='1';
    fseek(canal,(num_cli-1)*sizeof(struct cliente),SEEK_SET);
    fwrite(&cli,sizeof(struct cliente),1,canal);
   }
  }while(pregunte_s_n("M�s altas?(S/N):")=='S');
  fclose(canal);
}

void bajas()
{
  FILE *canal;
  struct cliente cli;
  int num_cli;
  while((canal=fopen("CLIENTES","r+b"))==NULL)
  {
    canal=fopen("CLIENTES","wb");
    fclose(canal);
  }
  do
  {
   pantalla_datos();
   gotoxy(21,7);
   do
   {
    gotoxy(21,7);printf("		");
    gotoxy(21,7);scanf("%d",&num_cli);
   }while(num_cli<1||num_cli>MAX);
   cli.control_alta='0';
   fseek(canal,(num_cli-1)*sizeof(struct cliente),SEEK_SET);
   fread(&cli,sizeof(struct cliente),1,canal);
   if(cli.control_alta!='1')
   {
    gotoxy(10,20);printf("Cliente no existente");
    continue;
   }
   gotoxy(21,9);printf("%s",cli.nombre);
   gotoxy(21,11);printf("%s",cli.direccion);
   gotoxy(21,13);printf("%d",cli.tipo);
   gotoxy(25,13);printf("Cliente %s",tipos[cli.tipo-1]);
   gotoxy(65,13);printf("%d",descuentos[cli.tipo-1]);
   if(pregunte_s_n("Confirma la baja?(S/N):")=='S')
   {
    cli.control_alta='0';
    fseek(canal,(num_cli-1)*sizeof(struct cliente),SEEK_SET);
    fwrite(&cli,sizeof(struct cliente),1,canal);
   }
  }while(pregunte_s_n("M�s bajas?(S/N):")=='S');
  fclose(canal);
}

void modificaciones()
{
  FILE *canal;
  struct cliente cli;
  int num_cli;
  while((canal=fopen("CLIENTES","r+b"))==NULL)
  {
    canal=fopen("CLIENTES","wb");
    fclose(canal);
  }
  do
  {
    pantalla_datos();
    gotoxy(21,7);
    do
    {
       gotoxy(21,7);printf("		");
       gotoxy(21,7);scanf("%d",&num_cli);
    }while(num_cli<1||num_cli>MAX);
    cli.control_alta='0';
    fseek(canal,(num_cli-1)*sizeof(struct cliente),SEEK_SET);
    fread(&cli,sizeof(struct cliente),1,canal);
    if(cli.control_alta!='1')
    {
      gotoxy(10,20);printf("Cliente no existente");
      continue;
    }
    gotoxy(21,9);printf("%s",cli.nombre);
    gotoxy(21,11);printf("%s",cli.direccion);
    gotoxy(21,13);printf("%d",cli.tipo);
    gotoxy(25,13);printf("Cliente %d",tipos[cli.tipo-1]);
    gotoxy(65,13);printf("%d",descuentos[cli.tipo-1]);
    if(pregunte_s_n("Modificar nombre?(S/N):")=='S')
    {
      gotoxy(21,9);printf("		");
      gotoxy(21,9);scanf("%s",cli.nombre);
    }
    if(pregunte_s_n("Modificar direccion?(S/N):")=='S')
    {
      gotoxy(21,11);printf("		");
      gotoxy(21,11);scanf("%s",cli.direccion);
    }
    if(pregunte_s_n("Modificar tipo?(S/N):")=='S')
    {
       gotoxy(21,13);printf("  ");
       gotoxy(25,13);printf("		");
       gotoxy(65,13);printf("	");
       do
       {
	 gotoxy(21,13);printf("		");
	 gotoxy(21,13);scanf("%d",&cli.tipo);
       }while(cli.tipo<1||cli.tipo>5);
       gotoxy(25,13);printf("Cliente %s",tipos[cli.tipo-1]);
       gotoxy(65,13);printf("%d",descuentos[cli.tipo-1]);
    }
    if(pregunte_s_n("Confirma la modificacion?(S/N):")=='S')
    {
       fseek(canal,(num_cli-1)*sizeof(struct cliente),SEEK_SET);
       fwrite(&cli,sizeof(struct cliente),1,canal);
    }
  }while(pregunte_s_n("M�s modificaciones?(S/N):")=='S');
  fclose(canal);
}

void consultas()
{
 struct limites limite;
 FILE *canal;
 struct cliente cli;
 int num_cli,i;
 while((canal=fopen("CLIENTES","r+b"))==NULL)
 {
    canal=fopen("CLIENTES","wb");
    fclose(canal);
 }
 limite=desde_hasta();
 num_cli=limite.inicio;
 while(num_cli<=limite.fin)
 {
    i=0;
    cabeceras();
    while(i<LV&&num_cli<=limite.fin)
    {
      cli.control_alta='0';
      fseek(canal,(num_cli-1)*sizeof(struct cliente),SEEK_SET);
      fread(&cli,sizeof(struct cliente),1,canal);
      if(cli.control_alta=='1')
      {
	printf("%3d%-20s%-20s Cliente %-15s%2d\n",num_cli,cli.nombre,
			cli.direccion,tipos[cli.tipo-1],descuentos[cli.tipo-1]);
	i++;
      }
      num_cli++;
    }
    if(pregunte_s_n("�Continuar?(S/N):")=='N') break;
 }
 fclose(canal);
}

void pantalla_datos()
{
  clrscr();
  gotoxy(35,2);printf("DATOS DE CLIENTES");
  gotoxy(35,3);printf("=================");
  gotoxy(5,7);printf("N� DE CLIENTE:");
  gotoxy(5,9);printf("    NOMBRE: ");
  gotoxy(5,11);printf("  DIRECCION: ");
  gotoxy(5,13);printf("     TIPO: ");
  gotoxy(50,13);printf("DESCUENTO(%):");
  gotoxy(3,16);printf("TIPOS DE CLIENTES:\n");
  printf("1->contado,2->normal,3->preferente,4->especial,5->extra");
}

char pregunte_s_n(char *cadena)
{
  char respuesta;
  gotoxy(10,22);printf("%s",cadena);
  while(respuesta=toupper(getch()),respuesta!='S'&&respuesta!='N');
  gotoxy(10,22);printf("%50s","");
  return(respuesta);
}

struct limites desde_hasta()
{
   struct limites l;
   clrscr();
   gotoxy(10,10);printf("Visualizar desde:");scanf("%d",&l.inicio);
   if(l.inicio==0) l.inicio=1;
   gotoxy(10,12);printf("Visualizar hasta: ");scanf("%d",&l.fin);
   if(l.fin==0||l.inicio>l.fin||l.fin>MAX) l.fin=MAX;
   clrscr();
   return l;
}

void cabeceras()
{
  clrscr();
  printf("%-20s %-28s %-10s %12s\n","NOMBRE","DIRECCION","TIPO","DESCUENTO");
  printf("=======================================================================\n");
}





