 #include <conio.h>
 #include <string.h>
 #include <stdio.h>
 #include <alloc.h>
 #include <stdlib.h>
 #include <dos.h>
 #define gopri(a,b,c) gotoxy(a,b); cprintf(c);
 #define color(a,b) textcolor(a);textbackground(b);

 void ventana(int,int,int,int);
 void menualtas();
 void menubajas();void bajaalumno();void bajaasig();
 void modifi();
 void visualiza();void v1isualiza();void visasig();
 void ordena();
 void menuvisu();
 void listasig();void lisalum();void menulist();void lisord();
 void altex();
 void altfrac();
 void dni();void clave();int confirma();

 main()
 {
      int d,c,s;
      d=1;
      while(d!=6)
      {
         window(1,1,80,25);
         textmode(2);
	   color(0,7);
         clrscr();
	   ventana(3,3,21,15);
         d=1;
         c=1;
         do{
            color(0,7);
		gopri(2,2," ALTAS ");
		gopri(2,4," BAJAS ");
		gopri(2,6," LISTADOS ");
		gopri(2,8," VISUALIZACIONES ");
		gopri(2,10," MODIFICACIONES ");
		gopri(2,12," FIN ");
            if(d==0) d=6;
            if(d==7) d=1;
            color(143,0);
            switch(d)
            {
		  case 1 :gopri(2,2," ALTAS ");
                       break;
		  case 2 :gopri(2,4," BAJAS ");
                       break;
		  case 3 :gopri(2,6," LISTADOS ");
                      break;
		  case 4 :gopri(2,8," VISUALIZACIONES ");
                       break;
		  case 5 :gopri(2,10," MODIFICACIONES ");
			     break;
		  case 6 :gopri(2,12," FIN ");
                      break;
            }
            c=getch();
            if(c==72) d=d-1;
            if(c==80) d=d+1;
         }while(c!=13);
         switch(d)
         {
            case 1 :menualtas();
                     break;
		case 2 :menubajas();
		     break;
		case 3 :menulist();
		     break;
		case 4 :menuvisu();
		     break;
		case 5 :modifi();
		     break;
         }
      }
}

void ventana(int a,int b,int c,int d)
{
        int col,fil;
        gotoxy(a-1,b-1);
        cprintf("�\b");
        gotoxy(c+1,b-1);
        cprintf("�\b");
        gotoxy(a-1,d+1);
        cprintf("�\b");
        gotoxy(c+1,d+1);
        cprintf("�\b");
        for(col=a;col<=c;col++)
        {
           gotoxy(col,b-1);
           cprintf("�\b");
           gotoxy(col,d+1);
           cprintf("�\b");
        }
        for(fil=b;fil<=d;fil++)
        {
           gotoxy(a-1,fil);
           cprintf("�\b");
           gotoxy(c+1,fil);
           cprintf("�\b");
        }
	window(a,b,c,d);
	clrscr();
 }

int confirma()
{
  char p;
  window(1,1,80,25);
  color(0,7);
  ventana(35,15,70,20);
  gopri(2,2," PULSA UNA TECLA PARA EMPEZAR ");
  gopri(2,4," O <ESC> PARA SALIR ");
  p=getch();
  if (p==27) return(-1);
  else return(1);
}

void dni()
{
   char c,s[10];int i;
   window(1,1,80,25);
   color(0,7);
   ventana(35,15,70,20);
   do{
      clrscr();
      gopri(2,2," INTRODUZCA LA CLAVE ");
	gotoxy(5,4);i=0;
      while((c=getche())!=13&&i<8)
      {
	 if(c==8) i-=1;
	 else
	 {
	   s[i++]=c;s[i]='\0';
	 }
      }
      clrscr();
      gopri(2,2," �ES CORRECTO ESTA CLAVE?(s/n) ");
	gotoxy(5,3);
      cprintf("%8s",s);
      gotoxy(2,5);
      c=getch();
   }while(c!='s'&&c!='S');
}


void menualtas()
{
 if(confirma()==-1) return;
 dni();
}

void modifi()
{
 if(confirma()==-1) return;
 dni();
}

void menubajas()
{
  int d=1;
  char c;
  window(1,1,80,25);color(0,7);ventana(5,8,23,16);
  do{
	gopri(2,2," DE CLAVE 1");
	gopri(2,5," DE CLAVE 2");gopri(2,8," SALIR A MENU");
      if(d==0) d=3;
      if(d==4) d=1;color(143,0);
      switch(d){
	 case 1 :gopri(2,2," DE CLAVE 1");
		       break;
	 case 2 :gopri(2,5," DE CLAVE 2");
		       break;
	 case 3 :gopri(2,8," SALIR A MENU");
		       break;
      }
      c=getch();if(c==72) d=d-1;if(c==80) d=d+1;
      color(0,7);
   }while(c!=13);
   switch(d){
      case 1 : bajaasig();
		 break;
      case 2 : bajaalumno();
		  break;
   }
}
void bajaasig()
{
 if (confirma()==-1) return;
 dni();
}

void bajaalumno()
{
 dni();
}


void menuvisu()
{
 int d=1;char c;
 window(1,1,80,25);color(0,7);
 ventana(5,12,23,20);clrscr();
 do{
  gopri(2,2," DE CLAVE 1");
  gopri(2,4," DE CLAVE 2");
  gopri(2,6," ORDENADAS");
  gopri(2,8," SALIR A MENU");
  if(d==0) d=4;
  if(d==5) d=1;
  color(143,0);
  switch(d){
     case 1 :gopri(2,2," DE CLAVE 1");
			  break;
     case 2 :gopri(2,4," DE CLAVE 2");
		  break;
     case 3 :gopri(2,6," ORDENADAS");
		  break;
     case 4 :gopri(2,8," SALIR A MENU");
  }
  c=getch();
  if(c==72) d=d-1;
  if(c==80) d=d+1;
  color(0,7);
 }while(c!=13);
 switch(d){
   case 1 :visualiza();
		break;
   case 2 :visasig();
		break;
   case 3 :ordena();v1isualiza();
		 break;
   case 4 :;
 }
}
void visualiza()
{
  int num2=0,i=1;
  char c,y[10];
  if(num2==0)
  {
     window(1,1,80,25);color(0,7);
     ventana(30,10,50,14);
     gopri(2,2," NO HAY REGISTROS ");
     gopri(2,4," PULSA UNA TECLA ");getch();
     return;
  }
  window(1,1,80,25);
  color(0,7);
  ventana(40,10,75,15);
  gopri(2,2,"INTRODUCE LA CLAVE INICIAL:");gotoxy(7,3);
  while((c=getche())!=13&&i<8)
  {
	 if(c==8) i-=1;
	 else
	 {
	   y[i++]=c;y[i]='\0';
	 }
  }
  gopri(2,4,"INTRODUCE EL CLAVE FINAL:");gotoxy(7,5);i=0;
  while((c=getche())!=13&&i<8)
  {
         if(c==8) i-=1;
	 else
	 {
	   y[i++]=c;y[i]='\0';
	 }
  }
}

void v1isualiza()
{
char c;
window(1,1,80,25);color(0,7);
do{
  ventana(30,10,71,16);clrscr();
  gopri(2,2,"PARA VISUALIZAR TODOS LOS REGISTROS PULSA 1");
  gopri(2,4," Y PARA VISUALIZAR SOLO PARTE ");
  gopri(2,6,"       DE LOS REGISTROS PULSA 2");
  c=getch();
}while(c!='1'&&c!='2');
}

void visasig()
{
 window(1,1,80,25);color(0,7);
 gopri(35,13," CLAVE DE LA PRIMERA BUSQUEDA");
 window(1,1,80,25);
 gopri(35,13," CLAVE DE LA SEGUNDA BUSQUEDA ");
}

void menulist()
{
 int d=1;
 char c;
 window(1,1,80,25);color(0,7);
 ventana(5,10,23,18);
 do{
  gopri(2,2," DE CLAVE 1");
  gopri(2,4," DE CLAVE 2");
  gopri(2,6," ORDENADOS");
  gopri(2,8," SALIR A MENU");
  if(d==0) d=4;
  if(d==5) d=1;
  color(143,0);
  switch(d){
     case 1 :gopri(2,2," DE CLAVE 1");
			  break;
     case 2 :gopri(2,4," DE CLAVE 2");
		  break;
     case 3 :gopri(2,6," ORDENADOS");
		  break;
     case 4 :gopri(2,8," SALIR A MENU");
  }
  c=getch();
  if(c==72) d=d-1;
  if(c==80) d=d+1;
  color(0,7);
 }while(c!=13);
 switch(d){
   case 1 :lisalum();
		break;
   case 2 :listasig();
		 break;
   case 3 :ordena();lisord();
		 break;
   case 5 :;
 }
}

void ordena()
{
}

void lisord()
{
char c;
window(1,1,80,25);color(0,7);
do{
	ventana(30,10,75,16);clrscr();
  gopri(2,2,"PARA LISTAR TODOS LOS REGISTROS PULSA 1");
  gopri(2,4," Y PARA LISTAR SOLO LOS PENDIENTES");
  gopri(2,6,"     PULSA 2");
  c=getch();
}while(c!='1'&&c!='2');
}

void listasig()
{
 window(1,1,80,25);
 gopri(35,13," CLAVE DE LA PRIMERA BUSQUEDA");
 window(1,1,80,25);
 gopri(35,13," CLAVE DE LA SEGUNDA BUSQUEDA");
}
void lisalum()
{
  int num2=0;
  if(num2==0)
  {
     window(1,1,80,25);color(0,7);
     clrscr();
     ventana(30,10,50,14);
		 gopri(2,2," NO HAY REGISTROS");
		 gopri(2,4," PULSA UNA TECLA ");getch();
     return;
  }
	window(1,1,80,25);
	gopri(38,13," PRIMERA CLAVE");
	dni();
	window(1,1,80,25);
	gopri(38,13," CLAVE FINAL ");dni();
}
