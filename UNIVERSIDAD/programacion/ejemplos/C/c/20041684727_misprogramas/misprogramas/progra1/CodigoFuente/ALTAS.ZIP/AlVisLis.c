/*ejemplo de manejo de ficheros con funciones de segundo nivel*/
/*altas y visualizaciones de un fichero con acceso por clave*/
/*libro, pag. 181.*/

#include <string.h>
#include <stdio.h>
#include <conio.h>

const char colores[][7]={"Rojo","Verde","Azul","Blanco"};
const char tallas[][8]={"Peque�a","Grande"};
struct stock
{
	char descripcion[30];
	int unidades,precio;
	unsigned color: 2;
	unsigned talla: 1;
};
int num,f,nrc;

char menu();
void altas();
void visualiza();
void listado();
void busqueda(FILE*,char*);
void insercion(FILE*,struct stock);
int num_registros(char*);

main()
{
	num=num_registros("ALMACEN");
	while(1)
		{
		switch(menu())
			     {	case '1': altas();
					  break;
				case '2': visualiza();
					  break;
				case '3': listado();
					  break;
				case 'F': exit(0);
			     }
		}
}
char menu()
{	char op;
	clrscr();
	printf("1.....Altas\n");
	printf("2.....Visualizaciones\n");
	printf("3.....Listado\n");
	printf("F.....Fin\n\n"); printf("Elige opcion:");
	while(1);
	{
		switch(op=getche())
		{
			case 'f': op='F';
			case '1':
			case '2':
			case '3':
			case 'F': return(op);
			default: printf("\b\b\a");
		}
	}
}
void altas()
{
	struct stock artic;
	char s[31];
	unsigned a;
	FILE*canal;
	s[0]=29;
	while((canal=fopen("ALMACEN","r+b"))==NULL)
	{
		canal=fopen("ALMACEN","wb");
		fclose(canal);
	}
	clrscr();
	printf("Introcuce la descripcion del articulo:");
	cgets(s); busqueda(canal,&s[2]);
	if(f==1)
	{	printf("\nEl articulo ya existe. Pulsa una tecla...");
		getch();
	}
	else
	{	strcpy(artic.descripcion,&s[2]);
		printf("\n\nUnidades:");
		scanf("%d",&artic.unidades);
		printf("\nPrecio unitario:");
		scanf("%d",&artic.precio);
		printf("\nColor (0=Rojo,1=Verde,2=Azul,3=Blanco):");
		scanf("%u",&a);artic.color=a%4;
		printf("\nTalla (0=Peque�a,1=Grande):");
		scanf("%u",&a);artic.talla=a%2;
		insercion(canal,artic);
	}
	fclose(canal);
}
void visualiza()
{
	int i,j,LONREG=sizeof(struct stock);
	struct stock art;
	FILE *canal;
	if((canal=fopen("ALMACEN","rb"))==NULL)
	{
		printf("\nNo hay articulos");
		printf("\nPulsa una tecla...");getch();
		return;
	}
	clrscr();
	printf("\nARTICULOS EN STOCK\n");
	printf("NUMERO DE ARTICULOS %d\n",num);
	for(i=0;i<num;i++)
	{
		fseek(canal,i*LONREG,SEEK_SET);
		fread(&art,LONREG,1,canal);
		printf("\nDESCRIPCION: %s",art.descripcion);
		printf("\nUNIDADES: %d",art.unidades);
		printf("\nPRECIO UNITARIO: %d",art.precio);
		j=art.color; printf("\nCOLOR: %s",colores[j]);
		j=art.talla; printf("\nTALLA: %s",tallas[j]);
		printf("\n--------------------------------------");
	}
	printf("\n\nPulsa una tecla para continuar...");
	getch();
	fclose(canal);
}
void listado()
{
	int i,j,LONREG=sizeof(struct stock);
	struct stock art;
	FILE*canal;
	if((canal=fopen("ALMACEN","rb"))==NULL)
	{
		printf("\nNo hay articulos");
		printf("\nPulsa una tecla...");
		getch();
		return;
	}
	clrscr();
	printf("\nPon a punto la impresora y pulsa una tecla");
	getch();
	fprintf(stdprn,"Articlos en stock\r\n");
	fprintf(stdprn,"Numero de articulos %d\r\n",num);
	for(i=0;i<num;i++)
	{
		fread(&art,LONREG,1,canal);
		fprintf(stdprn,"Descripcion: %s\r\n",art.precio);
		j=art.color;
		fprintf(stdprn,"COLOR:%s\r\n",colores[j]);
		j=art.talla;
		fprintf(stdprn,"TALLA:%s\r\n",tallas[j]);
		fprintf(stdprn,"--------------------------------\r\n");
	}
	printf("\n\nPulsa una tecla para continuar...");
	getch();
	fclose(canal);
}
void busqueda(FILE*canal,char*s)
{
	int a=0, b=num+1, m, compara;
	int LONREG=sizeof(struct stock);
	struct stock art;
	while(b-a>1)
	{
		m=(a+b)/2;
		fseek(canal,(m-1)*LONREG,SEEK_SET);
		fread(&art,LONREG,1,canal);
		compara=strcmp(art.descripcion,s);
		if(compara==0)
		{
			f=1;
			nrc=m;
			return;
		}
		else	if(compara>0) b=m;
			else a=m;
		}
		nrc=b;
		f=0;
	}
void insercion(FILE*canal,struct stock art)
{
	int i,LONREG=sizeof(struct stock);
	struct stock*p;
	for(i=num;i>nrc;i--);
	{	fseek(canal,(i-1)*LONREG,SEEK_SET);
		fread(p,i*LONREG,1,canal);
		fseek(canal,i*LONREG,SEEK_SET);
		fwrite(p,LONREG,1,canal);
	}
	fseek(canal,(nrc-1)*LONREG,SEEK_SET);
	fwrite(&art,LONREG,1,canal);
	num++;
}
int num_registros(char*c)
{
	FILE*canal;
	long l;
	if((canal=fopen(c,"rb"))==NULL) return(0);
	fseek(canal,0,SEEK_END);                     /*errata libro*/
	l=ftell(canal)/sizeof(struct stock);
	fclose(canal);
	return(l);
}