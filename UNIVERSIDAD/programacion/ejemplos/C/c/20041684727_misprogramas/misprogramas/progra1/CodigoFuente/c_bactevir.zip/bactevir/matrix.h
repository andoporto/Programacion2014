#ifndef _FUNCIONES_ADICIONALES_A_BACTEVIR_CPP
#define _FUNCIONES_ADICIONALES_A_BACTEVIR_CPP

//DEFINICI~N DE CONSTANTES LITERALES
#define ESC   27                                 //Tecla de escape
#define ENTER 13                                 //ASCCI correspondiente a ENTER    
#define TAM   19                                 //M~axima dimensi~on admitida para la matriz que aloja a las bacterias
#define exi  "<<Gracias por usar el Software>>"  //mensaje de salida del programa
#define nace  1
#define muere 0
#define myemi "->felixcriv@msn.com<-"

//DEFINICI~N DE PROCEDIMIENTOS PROTOTIPO [NOTA: EN C LOS PROCEDIMIENTOS SON SIMULADOS POR FUNCIONES
//                                        QUE NO ENTREGAN NINGUN VALOR, ES DECIR VACIAS (VOID)]

  
void info();								      //informaci~n en linea para el usuario
void evolution_mtrx();						 
void act_cuadro_1();						      //dibuja la superficie de reproduci~on
void act_cuadro_2();						      //dibuja un peque~o cuadro de di~logo
						 
int verifica(int sp);                             //verifica la validaci�n de datos de entrada

void mostrar___mtrx(int,        int [21][21]);    //ense�a si en matri[i][j] existe una bacteria [*], � de lo contrario si est� vac�a la posici�n
int  proximos(int,int,int,      int [21][21]);    //detecta si existe bacterias cercanas � tambi�n la cantidad que existen para aplicar las leyes de reproducci�n y convivencia de la colonia
void agrega(int,  int[21][21],  int [21][21]);    //llena la superficie de cultivo en matri[TAM][TAM]
void captura__mtrx(int &,int &, int [21][21]);    //nos permite llenar el arreglo asignandole posiciones fijas que se almacenan en memoria
int  simula_bacter(int,int,     int [21][21]);    //simula la reproducci~on de la colonia
void mostrar__mtrx();                             //dibuja una bacteria o una posici�n vac�a

/***********************************DEFINICI�N DE CLASES********************************/


class matrixclass //la utilizamos para realizar el proceso de entrada de datos a la matriz
{
public:
	int matri[21][21],auximat[21][21];           //superficie m�xima habitable para la colonia
	int w,p,q;                                   //acumula el n�mero de evoluciones posibles y las posiciones p,q para saber la posici�n de las bacterias pr�ximas (vecinas)
};

#endif //_FUNCIONES_ADICIONALES_A_BACTEVIR_CPP 