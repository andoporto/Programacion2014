
//bactevir.cpp
//Programa que simula la reproducci~on de una colonia bacteriana
//dependiendo de ciertas leyes que rigen su reproducci�n y convivencia.
//Desarrollado, compilado y ejecutado bajo MS-Visual C/C++ 6.0 bajo consola de WXP Pro. 
//Desarrollado F�lix C. Guerrero R.
//Instituto Universitario Tecnol�gico de Ejido. Extensi�n Bailadores.
//Bailadores- M�rida - Venezuela.Septiembre del 2003.
//Para m�s informaci�n acerca de los fundamentos de reproducci~on, ejecute
//el c�digo y seleccione el item 3 dentro del men~ de opciones principal.

//C�digos ASCII usados se generaron bajo ANSI Standar del Notepad de Windows
//Puedes usar partes del c�digo � algunos trucos najo consola que est�n aqu�,
//te ruego cuando hagas la copia del c�digo ense�a en los creditos este programa, as� estar�s
//contribuyendo a la creaci�n de c�digo reutilizable que seguir� desarrollando bajo este y otros lenguajes.
//Si apoyas al OpenSource puedes escribir una nota a mi correo, despu�s de todo piensa y reflexiona esto:
//"Ense��le al hombre a pescar, nunca le des la pesca", digo entonces que pienses en hacer c�digo de calidad y ayuda
//a mejorar (si puedes) el de los dem�s y despu�s comparte tu experiencia y conocimientos
//Lea primero LEAME.TXT.

//NOTAS IMPORTANTES: Consola es una librer�a desarrollda por los amigos programadores de la Universidad Nacional de M�xico, Hector Sagrado y Alex Bonzinelli
//Debes estar atento a los mensajes del fin de la pantalla como los de la barra de titulo de la ventana de consola windows, ellos
//te ir�n ayudando acerca del f�cil manejo del programa

//DEFINICI~N DE CABECERAS DEL PREPROCESADOR
#include <stdio.h>    //Input output (librer~a estandar)
#include <iostream.h> //Flujo de entrada y salida de c++
#include <conio.h>    //Libreria de operaciones por pantalla
#include <ctype.h>    //Libreria string components
#include <math.h>     //funciones matem~ticas
#include <stdlib.h>
#include <string.h>
#include "consola.h"  //Librer�a simplicada de estensiones de conio y dos.h
#include "matrix.h"   //Librer�a exclusiva para el manejo de las clases y directivas del preprocesador #define


char op;          //DEFINICI~ON DE VARIABLES GLOBALES

int i,j,k,h=0,c=0,ban;

 matrixclass vir;//objeto vir (virus) de tipo clase matrixclass

/****************************INICIO DEL PROGRAMA PRINCIPAL**********************************/
void main() 
{
  do 
  { 
   settitle("[Simulaci�n de una Colonia Bacteriana]                                        >>by felixcriv@msn.com");//establece el titulo de la ventana
   setsizedefault();//restaura la ventana en 80 filas por 25 columnas	   
   clrscr();
   textbackground(WHITE);
   textcolor(BLUE);
   clrscr();
  
   textbackground(YELLOW);
   _setcursortype(0);  //cursor oculto
   cprintf(" Simulaci�n de una Colonia de Bacterias Cecianas");
   clreol();

   textbackground(YELLOW);
   textcolor(BLUE);
   gotoxy(15,5);
   cprintf("Men� de Opciones");

   textbackground(WHITE);
   textcolor(BLUE);
   gotoxy(15,10);cprintf( "1. Introducir bacterias en la Colonia");
   gotoxy(15,13);cprintf("2. Ver el Proceso de Simulaci�n");
   gotoxy(15,16);cprintf("3. Lea primero antes de ejecutar el programa");

   gotoxy(1,25);
   textbackground(YELLOW);
   textcolor(BLUE);
   if (c)
   cprintf(" Datos cargados...                           [Presione 2 para ver la evoluci�n]");
   else
   cprintf(" Presione ESC para salir del programa � [Use las teclas 1,2,3 para seleccionar]");
   clreol();

   op=getche();
   switch (op)                                          //Sentencia de opciones, depende de las opciones mostradas en pantalla, [men�]
	  {
	    case '1':{ 
		          captura__mtrx(vir.w,vir.p,vir.matri);//Llenamos la matriz con las bacterias � casillas no habitadas    
			      break;
				 }

	    case '2':{ 
			       textbackground(WHITE);
			       clrscr();
				   if ((!c)&&((h>=1)||(h==0)))
				   {
					   settitle("Error de Usuario...");
					   textcolor(RED);
					   gotoxy(20,12);cprintf("\a\aNo se han cargado los datos de la Colonia!!\n");
					   gotoxy(12,14);cprintf("Los datos de la simulaci�n anterior fueron borrados de memoria");
					   gotoxy(22,16);cprintf(" Debes cargar los datos con la Opci�n 1!");
					   gotoxy(1,25);
					   textbackground(YELLOW);
					   textcolor(BLUE);
					   _setcursortype(0);
					   cprintf(" [Presione una tecla para continuar...]");
					   clreol();
					   getch();
				   }
				   else
				   {
				   h+=1;
				   for (k=1;k<=vir.p;k++)                    //permite ver evoluci�n por evoluci�n
				   {
		            for (i=1;i<=vir.w;i++)                   //nos permite desplazarmos fila por fila      
			          for (j=1;j<=vir.w;j++)                 //nos permite desplazarnos columna una a una
					  {
				        if (vir.matri[i][j]==muere)          //muere una bacteria
						{
					      vir.q=proximos(i,j,vir.w,vir.matri);//con q entregamos el n�mero de bacterias cercanas a matri[i][j]
					      if (vir.q==3)
						    vir.auximat[i][j]=nace;           //exactamente con 3 vecinos nace una bacteria en la posici�n matri[i][j]
					      else 
						    vir.auximat[i][j]=muere;          //la posici�n sigue no ocupada
						}
						else 	                              //si en la posici�n en la que estamos est� habitada por una bacteria
						{
					       vir.q=proximos(i,j,vir.w,vir.matri);//entrega el n�mero de vecinos que entrega la funci�n pr�ximos
						   if ((vir.q<2)||(vir.q>3))           //si hay menos de dos bacterias cercanas � tres
						     vir.auximat[i][j]=muere;          //la bacteria muere por aislamiento o asfixia
					       else 
						     vir.auximat[i][j]=nace;           //si no sigue, entonces sigue viva en matri[i][j]
						}
					  }
		             cin.get();                                   //para el proceso y espera una a que se oprima una tecla
		             cprintf(" ------------------------------------Evoluci�n %i-------------------------------\n",k);
					 textbackground(WHITE);
					 mostrar___mtrx(vir.w,vir.auximat); //ense�a por pantalla cada evoluci�n
					 settitle("Presione una tecla para ver la siguiente evoluci�n...");
		             agrega(vir.w,vir.auximat,vir.matri);         //pasa a la matriz principal los valores de la �ltima evoluci�n
				   }
				   c=0;
				   cin.get();
				   }
			break;
		    }

	  case '3':{
		         info();//breve descripci�n de bactevir.cpp
		         break;
			   }
	  default:  {//opci�n inexistente en el men� principal
		        if (op!=ESC)
				{
		         textbackground(WHITE);
		         clrscr();
		         gotoxy(8,12);
		         cprintf("� Opci�n inv�lida !, presione cualquier tecla para continuar...");		
		         getch();
		         break;
				}
			    else
                {
				 textbackground(WHITE);
				 clrscr();
				 settitle("Programa Finalizado...");
				 textcolor(RED);
				 gotoxy(26,20);
				 textcolor(BLUE);
				 _setcursortype(0);
				 for (i=0;i<=strlen(exi);i++)//imprime letra por letra el contenido de exi (mensaje de salida)
				 {
				   textcolor(BLUE);
				   gotoxy(23+i,8);
				   cprintf("%c",exi[i]);				 				   
				   delay(50);				   
				 }
				 for (i=0;i<=strlen(myemi);i++)//imprime letra por letra el contenido de myemi (mi email)
				 { 
				   textcolor(RED);
				   gotoxy(55+i,24);
			       cprintf("%c",myemi[i]);
				   delay(50);
				   textcolor(BLUE);
				 }
				 cout<<endl;cout<<endl;             
				 delay(1000);
				}
				}

	  }            //cierre del switch
  }                //cierre de la sentencia DO
  while (op!=ESC); //condici�n de retorno
}                  //cierre de void main()
/*******************************FIN DEL PROGRAMA PRINCIPAL**************************************/

/*******************************FUNCIONES Y PROCEDIMIENTOS***************************************/

//NOTA: En C/C++ los procedimientos se simulan por funciones que no entregan un valor en s�, al igual
//que en otros lenguajes los procedimientos pueden devolver m�s de un valor � conjunto de valores y las
//funciones devuelven (en C/C++ se dice retornan) un valor que debe conocer otra variable u otras funciones y/o
//procedimientos, esto realmente evita que escribamos tanto c�digo como fuera necesario para que las funciones y 
//procedimientos estuviesen en todas las partes en donde las invocamos
 
void captura__mtrx(int &w,int &p,int matri[21][21]) //captura las entradas de datos
{
	do
	{
	textcolor(BLUE);
	textbackground(WHITE);
	clrscr();
    gotoxy(1,1);
	textbackground(YELLOW);
	cprintf("Cultivo de Bacterias\n");
	textbackground(WHITE);
	cprintf("\n\nIndique la extensi�n de la superficie cuadricular del cultivo bacterial: ");
	cin>>w;
	ban=verifica(w);//valida la entrada en las dimensiones de la matriz de 1 x 1 hasta 20 x 20 
	}
	while (ban!=3);
	cout<<"    \nIndique un valor para las evoluciones de la Colonia bacterial          : ";
	cin>>p;
	cout<<endl; 
	
	for (i=1;i<=w;i++) 
	{
		for (j=1;j<=w;j++) 
		{
			
			gotoxy(1,8);
			cout<<"Indica si en la fila "<<i<<" columna "<<j<<" existe o no una bacteria (0=NO,1=SI): ";
			clreol();
			c=1;
			cin>>matri[i][j];  //entregamos a matri[i][j] el valor capturado
			gotoxy(15,10);
			textcolor(RED);
			cprintf("Representaci�n gr�fica de la matriz de bacterias");
			mostrar__mtrx();   //dibuja una bacteria [*] o una casilla vacia [0]
			textcolor(BLUE);
		}
	
	}	gotoxy(1,25);
        textbackground(YELLOW);
        textcolor(BLUE);
        _setcursortype(0);
        settitle("Captura de Datos finalizada...");
        cprintf(" [Presione una tecla para continuar...]");
		clreol();
        getch();
	
}



void mostrar___mtrx(int n,int matri[21][21]) //Dibuja las bacterias en disposici�n de matri[i][j]
{
int i,j;
	
	for (i=1;i<=n;i++) 
	{
		cout<<" ";                
		for (j=1;j<=n;j++)
			if (matri[i][j])
			{
				textcolor(RED);
				cprintf("*");       //nos dibuja una bacteria
			}
			else
			{
				textcolor(BLUE);
			    cprintf("0");       //dibuja una casilla no ocupada (vac�a)
			}
		cout<<endl;
		clreol();
	}
textcolor(BLUE);
}



int proximos(int i,int j,int n,int matri[21][21]) //calcula los vecinos que tiene cada casilla en [i][j]
{
	int vecinos=0;              //cada vez que se entra el n�mero de vecinos cambia de fila en fila
	if (i==1)                   //Primera fila
	{
		if (j==1)               //Primera columna		
		{
			
			vecinos+=simula_bacter(i,j+1,  matri);
			vecinos+=simula_bacter(i+1,j,  matri);
			vecinos+=simula_bacter(i+1,j+1,matri);
		}
		if ((j>1)&&(j<n)) //Columnas del medio de la matrix
		{ 
		
			vecinos+=simula_bacter(i,j-1,  matri);
			vecinos+=simula_bacter(i,j+1,  matri);
			vecinos+=simula_bacter(i+1,j-1,matri);
			vecinos+=simula_bacter(i+1,j,  matri);
			vecinos+=simula_bacter(i+1,j+1,matri);
		}
		if (j==n) //�ltima columa del arreglo
		{		
			vecinos+=simula_bacter(i,j-1,  matri);
			vecinos+=simula_bacter(i+1,j-1,matri);
			vecinos+=simula_bacter(i+1,j,  matri);
		}
	}
	if ((i>1)&&(i<n)) //filas del medio
	{
		if (j==1) //en la primera columna
		{
			vecinos+=simula_bacter(i-1,j,  matri);
			vecinos+=simula_bacter(i-1,j+1,matri);
			vecinos+=simula_bacter(i,j+1,  matri);
			vecinos+=simula_bacter(i+1,j,  matri);
			vecinos+=simula_bacter(i+1,j+1,matri);
		}
		if ((j>1)&&(j<n)) //columnas del medio
		{
		
			vecinos+=simula_bacter(i-1,j-1,matri);
			vecinos+=simula_bacter(i-1,j,matri);
			vecinos+=simula_bacter(i-1,j+1,matri);
			vecinos+=simula_bacter(i,j-1,matri);
			vecinos+=simula_bacter(i,j+1,matri);
			vecinos+=simula_bacter(i+1,j-1,matri);
			vecinos+=simula_bacter(i+1,j,matri);
			vecinos+=simula_bacter(i+1,j+1,matri);
		}
		if (j==n) //�ltima columna
		{
			vecinos+=simula_bacter(i-1,j-1,matri);
			vecinos+=simula_bacter(i-1,j,matri);
			vecinos+=simula_bacter(i,j-1,matri);
			vecinos+=simula_bacter(i+1,j-1,matri);
			vecinos+=simula_bacter(i+1,j,matri);
		}
	}
	if (i==n) //la ultima fila
	{
		if (j==1) //en la primera columna
		{
			
			vecinos+=simula_bacter(i-1,j,matri);
			vecinos+=simula_bacter(i-1,j+1,matri);
			vecinos+=simula_bacter(i,j+1,matri);
		}
		if ((j>1)&&(j<n)) //en las columnas del medio
		{		
			vecinos+=simula_bacter(i-1,j-1,matri);
			vecinos+=simula_bacter(i-1,j,matri);
			vecinos+=simula_bacter(i-1,j+1,matri);
			vecinos+=simula_bacter(i,j-1,matri);
			vecinos+=simula_bacter(i,j+1,matri);
		}
		if (j==n) //ultima columna
		{
			vecinos+=simula_bacter(i-1,j-1,matri);
			vecinos+=simula_bacter(i-1,j,matri);
			vecinos+=simula_bacter(i,j-1,matri);
		}
	}
	return vecinos;//entrega los vecinos 
}
	

	
	
int simula_bacter(int i,int j,int matri[21][21]) //Verifica si un vecino es bacteria � esta vacio
{
	if (matri[i][j]==nace)//si es bacteria 
		return nace;//devuelve una bacteria que se va acumulando
	else 
		return muere;//no es bacteria
}

void agrega(int n,int auximat[21][21],int matri[21][21]) //hace un paso de contenido de la matrix auxiliar a la principal
{
int i,j;
	for (i=1;i<=n;i++)
		for (j=1;j<=n;j++)
			matri[i][j]=auximat[i][j];//hace la copia de valores
}


void info()//breve rese�a del programa
{
 textbackground(WHITE);
 textcolor(BLUE);
 clrscr();
 settitle("Acerca del Programa de Simulaci�n de Colonia Bacteriana");
 textbackground(YELLOW);
 cprintf(" Lea Primerio [Sinopsis del Programa de Simulaci�n Bacteriana]");
 clreol();
 textbackground(WHITE);
 cprintf("\n\nEste programa simula la reproducci�n de 'n' bacterias distribuidas en una\n");
 cprintf("\nsuperficie de 'n' casillas, estableciendo que la matriz de distribuci�n\n");
 cprintf("\ntiene por l�mite la capacidad de 20 filas por 20 columnas, es decir, 400\n");
 cprintf("\nposiciones � casillas que puede habitar � no una bacteria.\n");
 cprintf("\nLas bacterias est�n sujetas a las siguientes variables que controlan\n");
 cprintf("\nsu reproducci�n:\n\n\n");
 cprintf("\n1. Nacimiento: en casilla vac�a con tre vecinos");
 cprintf("\n2. Muerte por aislamiento: si una bacteria tiene uno o ningun vecino");
 cprintf("\n3. Muerte por asfixia: si una bacteria tiene m�s de tres vecinos");
 cprintf("\n4. Supervivencia: si una bacteria tiene dos o tres vecinos");
 gotoxy(1,25);
 textcolor(BLUE);
 textbackground(YELLOW);
 _setcursortype(2);
 cprintf("Presione una tecla para salir...");
 clreol();
 getch();
}

int verifica(int sp)//verifica que el valor de la dimensi�n de la superficie es permitida
{
   textcolor(RED);
   if (sp>20)
    {
     act_cuadro_2();
     gotoxy(8,20);
     cprintf("La superficie l�mite es de 20 x 20, indique un n�mero menor ");
     getch();
     clrscr();
     return 1;
    }
    else
      if (sp<=0)
      {
       clreol();
       act_cuadro_2();
       gotoxy(8,20);
       cprintf("Debe ser entero (sin parte decimal) positivo mayor � igual a 1");
       getch();
       clrscr();
       return 2;
      }
     else
     {
	     textcolor(BLUE);
		 return 3;//entonces el valor est� en los l�mites establecidos
	 }
}



void act_cuadro_2()//dibuja un peque�o cuadro de dos lineas
{
 for (i=0;i<=67;i++)
     {
      gotoxy(5+i,19);
      cprintf("�");
     }
	 for (i=0;i<=67;i++)
     {
      gotoxy(5+i,21);
      cprintf("�");
     }
}
void mostrar__mtrx()//ense�a la matrix con sus bacterias o posiciones vac�as
{
  if (!(vir.matri[i][j]))
    {
     textcolor(BLUE);
     gotoxy(2+j,11+i);
     cprintf("0");   //si en la casilla no hay una bacteria
		             //se imprimir� un cero (0)
    }
  else
     {
      textcolor(RED);
      gotoxy(2+j,11+i);
      cprintf("*");  //se imprime una bacteria
	  textcolor(BLUE);
     }
    /*fin de la estructura de mostrado por pantalla*/
}
/***************************FIN DE LAS FUNCIONES Y PROCEDIMIENTOS***************************/
