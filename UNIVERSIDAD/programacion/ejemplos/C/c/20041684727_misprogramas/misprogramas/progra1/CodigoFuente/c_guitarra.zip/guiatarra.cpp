/*////////////////////////////////////////////////////////////////////////////////////////

       Porgrama que muestra el brazo de una guitarra, con las flechas del teclado te puedes
       ir dezplazando entre los trastes y las cuerdas de la guiatarra y al oprimir enter
       escucharas el sonido de dicha cuerda. Oprimiendo el boton 1 puedes comenzar a
       grabar una secuencia de sonidos cada que oprimes enter y con la tecla 2 reproducir
       la secuencia de sonidos graabada.

       Realizado por Carlos Escondrillas y Compilado en Borland C++ Version 5

 ////////////////////////////////////////////////////////////////////////////////////////*/



#include <dos.h>
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>

void main (void)
 {
  int frec[6][19],ipx,ipy,iv,in,ia;
  int posicionx[19],posiciony[6],graba[200];
  char c;
  ipx=ipy=in=iv=0;

  printf("\n PROGRAMA QUE SIMULA LOS SONIDOS DE UNA GUITARRA Y GRABA UNA SECUENCIA DE NOTAS\n\n");
  printf(" |---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|M|||\n");
  printf(" |---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|A|||\n");
  printf(" |---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|D|||\n");
  printf(" |---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|G|||\n");
  printf(" |---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|B|||\n");
  printf(" |---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|M|||\n");
  printf("\n\n\n\t Presione la tecla 1 para comenzar la grabacion de menos de 200 notas.");
  printf("\n\t Presione la tecla 2 para comenzar la reproduccion.");
  printf("\n\t Presione la tecla 3 para borrar la grabacion.");
  printf("\n\t Presione la tecla escape para salir del programa.");

  frec[0][0]=470; //la#3//
  frec[0][1]=440;
  frec[0][2]=418;
  frec[0][3]=391;
  frec[0][4]=371;
  frec[0][5]=348;
  frec[0][6]=330;
  frec[0][7]=313;
  frec[0][8]=293;
  frec[0][9]=278;
  frec[0][10]=261;
  frec[0][11]=248;
  frec[0][12]=235;
  frec[0][13]=220;
  frec[0][14]=209;
  frec[0][15]=196;
  frec[0][16]=186;
  frec[0][17]=174;
  frec[0][18]=165;

  frec[1][0]=626;
  frec[1][1]=587;
  frec[1][2]=557;
  frec[1][3]=521;
  frec[1][4]=495;
  frec[1][5]=470;
  frec[1][6]=440;
  frec[1][7]=418;
  frec[1][8]=391;
  frec[1][9]=371;
  frec[1][10]=348;
  frec[1][11]=330;
  frec[1][12]=313;
  frec[1][13]=293;
  frec[1][14]=278;
  frec[1][15]=261;
  frec[1][16]=248;
  frec[1][17]=235;
  frec[1][18]=220;

  frec[2][0]=835;
  frec[2][1]=782;
  frec[2][2]=743;
  frec[2][3]=695;
  frec[2][4]=660;
  frec[2][5]=626;
  frec[2][6]=587;
  frec[2][7]=557;
  frec[2][8]=521;
  frec[2][9]=495;
  frec[2][10]=470;
  frec[2][11]=440;
  frec[2][12]=418;
  frec[2][13]=391;
  frec[2][14]=371;
  frec[2][15]=348;
  frec[2][16]=330;
  frec[2][17]=313;
  frec[2][18]=293;

  frec[3][0]=1114;
  frec[3][1]=1043;
  frec[3][2]=990;
  frec[3][3]=940;
  frec[3][4]=880;
  frec[3][5]=835;
  frec[3][6]=782;
  frec[3][7]=743;
  frec[3][8]=695;
  frec[3][9]=660;
  frec[3][10]=626;
  frec[3][11]=587;
  frec[3][12]=557;
  frec[3][13]=521;
  frec[3][14]=495;
  frec[3][15]=470;
  frec[3][16]=440;
  frec[3][17]=418;
  frec[3][18]=391;

  frec[4][0]=1391;
  frec[4][1]=1320;
  frec[4][2]=1253;
  frec[4][3]=1173;
  frec[4][4]=1114;
  frec[4][5]=1043;
  frec[4][6]=990;
  frec[4][7]=940;
  frec[4][8]=880;
  frec[4][9]=835;
  frec[4][10]=782;
  frec[4][11]=743;
  frec[4][12]=695;
  frec[4][13]=660;
  frec[4][14]=626;
  frec[4][15]=587;
  frec[4][16]=557;
  frec[4][17]=521;
  frec[4][18]=495;

  frec[5][0]=1879;
  frec[5][1]=1760;
  frec[5][2]=1671;
  frec[5][3]=1564;
  frec[5][4]=1485;
  frec[5][5]=1391;
  frec[5][6]=1320;
  frec[5][7]=1253;
  frec[5][8]=1173;
  frec[5][9]=1114;
  frec[5][10]=1043;
  frec[5][11]=990;
  frec[5][12]=940;
  frec[5][13]=880;
  frec[5][14]=835;
  frec[5][15]=782;
  frec[5][16]=743;
  frec[5][17]=695;
  frec[5][18]=660;

  posicionx[0]=4;
  posicionx[1]=8;
  posicionx[2]=12;
  posicionx[3]=16;
  posicionx[4]=20;
  posicionx[5]=24;
  posicionx[6]=28;
  posicionx[7]=32;
  posicionx[8]=36;
  posicionx[9]=40;
  posicionx[10]=44;
  posicionx[11]=48;
  posicionx[12]=52;
  posicionx[13]=56;
  posicionx[14]=60;
  posicionx[15]=64;
  posicionx[16]=68;
  posicionx[17]=72;
  posicionx[18]=75;
  posiciony[0]=4;
  posiciony[1]=5;
  posiciony[2]=6;
  posiciony[3]=7;
  posiciony[4]=8;
  posiciony[5]=9;



  for(;;)
  {
   gotoxy(posicionx[ipx],posiciony[ipy]);
   printf("*");
   c=getch();
   switch (c)
    {
     case 72:
      gotoxy(posicionx[ipx],posiciony[ipy]);
      if(ipx==18)
       {
        if(ipy==0)
        printf("M");
        if(ipy==1)
        printf("A");
        if(ipy==2)
        printf("D");
        if(ipy==3)
        printf("G");
        if(ipy==4)
        printf("B");
        if(ipy==5)
        printf("M");
       }

      else
       {
        printf("-");
       }

      ipy--;
      if(ipy==-1)
        ipy=5;
     break;

     case 80:
      gotoxy(posicionx[ipx],posiciony[ipy]);
      if(ipx==18)
       {
        if(ipy==0)
        printf("M");
        if(ipy==1)
        printf("A");
        if(ipy==2)
        printf("D");
        if(ipy==3)
        printf("G");
        if(ipy==4)
        printf("B");
        if(ipy==5)
        printf("M");
       }

      else
       {
        printf("-");
       }

      ipy++;
      if(ipy==6)
        ipy=0;
     break;

     case 77:
      gotoxy(posicionx[ipx],posiciony[ipy]);
      if(ipx==18)
       {
        if(ipy==0)
        printf("M");
        if(ipy==1)
        printf("A");
        if(ipy==2)
        printf("D");
        if(ipy==3)
        printf("G");
        if(ipy==4)
        printf("B");
        if(ipy==5)
        printf("M");
       }

      else
       {
        printf("-");
       }
      ipx++;
      if(ipx==19)
        ipx=0;
     break;

     case 75:
      gotoxy(posicionx[ipx],posiciony[ipy]);
      if(ipx==18)
       {
        if(ipy==0)
        printf("M");
        if(ipy==1)
        printf("A");
        if(ipy==2)
        printf("D");
        if(ipy==3)
        printf("G");
        if(ipy==4)
        printf("B");
        if(ipy==5)
        printf("M");
       }

      else
       {
        printf("-");
       }
      ipx--;
      if(ipx==-1)
        ipx=18;
     break;

     case 13:
      sound(frec[ipy][ipx]);
      delay(250);
	   nosound();
      if(iv==1)
       {
        if(in<200)
        {
         graba[in]=(frec[ipy][ipx]);
         in++;
        }
       else
        {
         gotoxy(1,17);
         printf("\tLa cantidad de sonidos ha sobrepasado los 200");
        }

       }

     break;

     case '1':
     gotoxy(1,17);
     printf("\t                                                     ");
      iv=1;
      in=0;
     break;

     case '2':
     gotoxy(1,17);
     printf("\t                                                     ");
      for(ia=0;ia<in;ia++)
       {
        sound(graba[ia]);
        delay(350);
        nosound();
       }
      iv=0;
     break;

     case '3':
     gotoxy(1,17);
     printf("\t                                                     ");
     in=0;
     break;

     case 27:
     exit(0);
     break;

     default:
     break;
    }
  }
 }
